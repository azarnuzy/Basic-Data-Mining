import pandas as pd, scipy, numpy as np
from flask import Flask, request, render_template
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import MultinomialNB

app = Flask(__name__)

ds = pd.read_csv('play_tennis.csv', usecols= ['outlook','temp','humidity','wind','play'])

# inspect some basic attributes of the data set
x = ds.iloc[:,:-1].values
y = ds.iloc[:,-1].values

encoder = LabelEncoder()

#Converting String Labels into numbers one column at a time
x[:,0] = encoder.fit_transform(x[:,0])
x[:,1] = encoder.fit_transform(x[:,1])
x[:,2] = encoder.fit_transform(x[:,2])
x[:,3] = encoder.fit_transform(x[:,3])
y = encoder.fit_transform(y)

# Create a Multinomial Naive Bayes Classifier
model = MultinomialNB()

#Train the model
model.fit(x, y)

@app.route('/')
def index():
    return render_template('index.html', predicted="")

@app.route('/prediction', methods=['POST'])
def prediction():
    outlook = int(request.form['outlook'])
    temp = int(request.form['temp'])
    humidity = int(request.form['humidity'])
    wind = int(request.form['wind'])
    
    predicted = model.predict([[outlook, temp, humidity, wind]]) #input coming as overcast and Mild
    
    if outlook == 0:
        outlook = "Overcast"
    elif outlook == 1:
        outlook = "Rain"
    elif outlook == 2:
        outlook = "Sunny"

    if temp == 0:
        temp = "Cool"
    elif temp == 1:
        temp = "Hot"
    elif temp == 2:
        temp = "Mild"

    humidity = "Normal" if humidity else "High"

    wind = "Weak" if wind else "Strong"

    return render_template('index.html', predicted = "Yes" if predicted else "No", outlook = outlook, temp = temp, humidity = humidity, wind = wind)

if __name__ == '__main__':
    app.run(debug=True)